package com.object.duck.behave;


import com.object.duck.model.BaseModel;


public abstract class LilyAppear extends ModelInitPosition {

    public LilyAppear(BaseModel baseModel) {
        super(baseModel);
    }
}
