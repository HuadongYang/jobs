package com.object.duck.behave;

public interface Whistle {

    void whistle();
}
