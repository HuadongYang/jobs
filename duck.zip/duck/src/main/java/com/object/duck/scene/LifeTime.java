package com.object.duck.scene;

public interface LifeTime {

    void lifeTime(String name);
}
