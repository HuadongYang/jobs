package com.object.duck.behave.impl;

import com.object.duck.behave.ModelInitPosition;
import com.object.duck.model.Rock;

public class RockAppearImpl extends ModelInitPosition {
    public RockAppearImpl(Rock rock) {
        super(rock);
    }
}
