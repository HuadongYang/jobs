package com.object.duck.model;

public class Rock extends BaseModel {
}
